//
//  NSDictionary+Addition.h
//  NeiHan
//
//  Created by Charles on 16/9/1.
//  Copyright © 2016年 Charles. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (Addition)

- (void)propertyCode;

@end
