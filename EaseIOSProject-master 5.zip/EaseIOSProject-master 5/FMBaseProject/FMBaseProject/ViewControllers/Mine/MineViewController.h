//
//  MineViewController.h
//  FMBaseProject
//
//  Created by shanjin on 2016/10/19.
//  Copyright © 2016年 付新明. All rights reserved.
//

#import "FXMBaseViewController.h"



@interface MineViewController : FXMBaseViewController


@end






