//
//  MineViewController.m
//  FMBaseProject
//
//  Created by shanjin on 2016/10/19.
//  Copyright © 2016年 付新明. All rights reserved.
//

#import "MineViewController.h"









@interface MineViewController ()

@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navBar.title = self.myTitle;
    self.view.backgroundColor = [UIColor greenColor];
    UIButton *btn = [FMUIUtil createBtnWithText:@"" font:[UIFont systemFontOfSize:30] textColor:[UIColor blackColor]];
    btn.frame = CGRectMake(100, 100, 100, 100);
    [btn addTarget:self action:@selector(btnClick) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
}

-(void)btnClick{
    FMRequestUtil *req = [FMRequestUtil sharedInstance];
    
    NSString *urlString = @"http://api.jisuapi.com/iqa/query?";
    NSDictionary *params = @{@"appkey":appkey_1,@"question":@"新乡天气"};
    [req POST:urlString dict:params succeed:^(id data) {
        NSLog(@"%@",data);
    } failure:^(NSError *error) {
        NSLog(@"%@",error.userInfo);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
