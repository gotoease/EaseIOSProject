//
//  AppDefines.h
//  FMBaseProject
//
//  Created by shanjin on 2017/5/25.
//  Copyright © 2017年 付新明. All rights reserved.
//

#ifndef AppDefines_h
#define AppDefines_h

#define FMRootNavPush(vc) [(UINavigationController *)[FMUtil appDelegate].window.rootViewController pushViewController:vc animated:YES]
#endif /* AppDefines_h */
