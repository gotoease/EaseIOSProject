//
//  FMAppUtil.h
//  FMBaseProject
//
//  Created by shanjin on 2017/5/24.
//  Copyright © 2017年 付新明. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FMAppUtil : NSObject
+ (void)goToLogin;
@end
