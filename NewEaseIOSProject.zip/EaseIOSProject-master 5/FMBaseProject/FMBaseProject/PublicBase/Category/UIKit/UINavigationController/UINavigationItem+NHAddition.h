//
//  UINavigationItem+NHAddition.h
//  NeiHan
//
//  Created by Charles on 16/9/8.
//  Copyright © 2016年 Charles. All rights reserved.
//  重写setter方法，修复item位置

#import <UIKit/UIKit.h>

@interface UINavigationItem (NHAddition)

@end
