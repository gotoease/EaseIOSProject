//
//  WorkViewController.m
//  FMBaseProject
//
//  Created by shanjin on 2016/10/19.
//  Copyright © 2016年 付新明. All rights reserved.
//

#import "WorkViewController.h"

@interface WorkViewController ()

@end

@implementation WorkViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navBar.title = self.myTitle;
    self.view.backgroundColor = [UIColor whiteColor];
}



@end
