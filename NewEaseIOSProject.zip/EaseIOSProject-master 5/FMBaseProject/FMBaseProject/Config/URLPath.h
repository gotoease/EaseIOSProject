//
//  URLPath.h
//  FMBaseProject
//
//  Created by shanjin on 2017/5/25.
//  Copyright © 2017年 付新明. All rights reserved.
//

#ifndef URLPath_h
#define URLPath_h
//天气预报接口
#define WeatherReport @"/common/weatherReport?"
#define WS_GetCityNames @"/dictInfo/getAllCitys"
#endif /* URLPath_h */
