//
//  MineViewController.m
//  FMBaseProject
//
//  Created by shanjin on 2016/10/19.
//  Copyright © 2016年 付新明. All rights reserved.
//

#import "MineViewController.h"


@interface MineViewController (){
    UIImageView *View;
    UIView *bgView;
    UITextField *pwd;
    UITextField *user;
    UIButton *QQBtn;
    UIButton *weixinBtn;
    UIButton *xinlangBtn;
    UIButton *imageView;
}

@end

@implementation MineViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    

    View=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    View.backgroundColor=[UIColor redColor];
    View.image=[UIImage imageNamed:@"bg4"];
    
    [self.view addSubview:View];
    
    UILabel *lanel=[[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width-30)/2, 25, 50, 30)];
    lanel.text=@"我";
    [self.view addSubview:lanel];
    
    
    //create white image
    CGRect frame=[UIScreen mainScreen].bounds;
    bgView=[[UIView alloc]initWithFrame:CGRectMake(0,60,frame.size.width, 120)];
    bgView.layer.cornerRadius=3.0;
    bgView.alpha=0.5;
    bgView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:bgView];
    
    
    bgView=[[UIView alloc]initWithFrame:CGRectMake(0,185,frame.size.width, 220)];
    bgView.layer.cornerRadius=3.0;
    bgView.alpha=0.5;
    bgView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:bgView];
    
    imageView=[[UIButton alloc]initWithFrame:CGRectMake(10, 10, 50, 50)];
    imageView.backgroundColor=[UIColor redColor];
    [self.view addSubview:bgView];
}

-(void)btnClick{
    FMRequestUtil *req = [FMRequestUtil sharedInstance];
    
    NSString *urlString = @"http://api.jisuapi.com/iqa/query?";
    NSDictionary *params = @{@"appkey":appkey_1,@"question":@"新乡天气"};
    [req POST:urlString dict:params succeed:^(id data) {
        NSLog(@"%@",data);
    } failure:^(NSError *error) {
        NSLog(@"%@",error.userInfo);
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
