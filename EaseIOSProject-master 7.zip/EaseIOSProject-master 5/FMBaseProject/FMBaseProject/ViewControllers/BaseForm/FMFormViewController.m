//
//  FMFormViewController.m
//  FMBaseProject
//
//  Created by shanjin on 2016/10/25.
//  Copyright © 2016年 付新明. All rights reserved.
//

#import "FMFormViewController.h"

@interface FMFormViewController (){
    UIImageView *View;
    UIView *bgView;
    UITextField *pwd;
    UITextField *user;
    UIButton *QQBtn;
    UIButton *weixinBtn;
    UIButton *xinlangBtn;
}
@property(copy,nonatomic) NSString * accountNumber;
@property(copy,nonatomic) NSString * mmmm;
@property(copy,nonatomic) NSString * user;
@end

@implementation FMFormViewController
@synthesize sectionArray;
@synthesize section0;
- (void)viewDidLoad {
    [super viewDidLoad];
    sectionArray = [NSMutableArray array];
    section0 = [RETableViewSection section];
    
    [self initView];
    
    
    
    //创建一个以bg4为背景的view界面
    
    
    self.navHidden = YES;
    View=[[UIImageView alloc]initWithFrame:CGRectMake(0, 70, self.view.frame.size.width, self.view.frame.size.height)];
    View.backgroundColor=[UIColor redColor];
    View.image=[UIImage imageNamed:@"bg4"];
    [self.view addSubview:View];
    
    
    
    UILabel *lanel=[[UILabel alloc]initWithFrame:CGRectMake((self.view.frame.size.width-30)/2, 30, 50, 30)];
    lanel.text=@"注册";
    lanel.textColor=[UIColor colorWithRed:248/255.0f green:144/255.0f blue:34/255.0f alpha:1];
    [self.view addSubview:lanel];
    
    
    
    [self createButtons];
    [self createImageViews];
    [self createTextFields];
    [self createLabel];
    
    
    
}

-(void)createButtons
{
    
    
    UIButton *landBtn =[[UIButton alloc]initWithFrame:CGRectMake(10, 290, self.view.frame.size.width-20, 37)];
    [landBtn setTitle:@"注册" forState:UIControlStateNormal];
    [landBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    landBtn.font=[UIFont systemFontOfSize:19];
    [landBtn addTarget:self action:@selector(landClick) forControlEvents:UIControlEventTouchDown];
    landBtn.backgroundColor=[UIColor colorWithRed:248/255.0f green:144/255.0f blue:34/255.0f alpha:1];
    landBtn.layer.cornerRadius=5.0f;
    [self.view addSubview:landBtn];
    
}

-(void)landClick
{
    
    FMRequestUtil *req = [FMRequestUtil sharedInstance];
    
    NSString *urlString = @"http://106.14.198.192:8080/EaseTest01/user/hello22";
    NSDictionary *params = @{@"username":user.text,@"email":@"xxx",@"password":pwd.text};
    
    [req POST:urlString dict:params succeed:^(id data) {
        NSLog(@"天一");
    } failure:^(NSError *error) {
        NSLog(@"梦琪");
    }];
    
    NSLog(@"success");
    NSLog(@"success");
    NSLog(@"success");
    NSLog(@"success");
    NSLog(@"success");
    NSLog(@"success");
    
    
}


-(void)createImageViews
{
   
    
}

-(void)createTextFields
{
    CGRect frame=[UIScreen mainScreen].bounds;
    bgView=[[UIView alloc]initWithFrame:CGRectMake(10, 75, frame.size.width-20, 150)];
    bgView.layer.cornerRadius=3.0;
    bgView.alpha=0.7;
    bgView.backgroundColor=[UIColor whiteColor];
    [self.view addSubview:bgView];
    
    
    UIButton *landBtn =[[UIButton alloc]initWithFrame:CGRectMake(10, 290, self.view.frame.size.width-20, 37) ];
    [landBtn setTitle:@"注册" forState:UIControlStateNormal];
    [landBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    landBtn.font=[UIFont systemFontOfSize:19];
    [landBtn addTarget:self action:@selector(landClick) forControlEvents:UIControlEventTouchDown];
    landBtn.backgroundColor=[UIColor colorWithRed:248/255.0f green:144/255.0f blue:34/255.0f alpha:1];
    landBtn.layer.cornerRadius=5.0f;
    [self.view addSubview:landBtn];
    
    
    UITextField *user=[[UITextField alloc]initWithFrame:CGRectMake(60, 10, 271, 30)];
    user.font=[UIFont systemFontOfSize:14];
    user.placeholder=@"请输入姓名";
    //user.text=@"13419693608";
    user.keyboardType=UIKeyboardTypeDefault;
    user.clearButtonMode = UITextFieldViewModeWhileEditing;
    [bgView addSubview:user];
    
    UITextField *email=[[UITextField alloc]initWithFrame:CGRectMake(60, 60, 271, 30)];
    email.font=[UIFont systemFontOfSize:14];
    email.placeholder=@"请输入邮箱";
    //user.text=@"13419693608";
    email.keyboardType=UIKeyboardTypeDefault;
    email.clearButtonMode = UITextFieldViewModeWhileEditing;
    [bgView addSubview:email];
    
    UITextField *pwd=[[UITextField alloc]initWithFrame:CGRectMake(60, 110, 271, 30)];
    pwd.font=[UIFont systemFontOfSize:14];
    pwd.placeholder=@"请输入密码";
    //pwd.text=@"13419693608";
    pwd.keyboardType=UIKeyboardTypeNumberPad;
    pwd.clearButtonMode = UITextFieldViewModeWhileEditing;
    email.keyboardType=UIKeyboardTypeNumberPad;
    pwd.secureTextEntry=YES;
    [bgView addSubview:pwd];
    
    //line1
    UIImageView *line1=[[UIImageView alloc]initWithFrame:CGRectMake(20, 50, bgView.frame.size.width-40, 1)];
    [line1 setBackgroundColor:[UIColor grayColor]];
    line1.alpha=0.3;
    [bgView addSubview:line1];
    //line2
    UIImageView *line2=[[UIImageView alloc]initWithFrame:CGRectMake(20, 100, bgView.frame.size.width-40, 1)];
    [line2 setBackgroundColor:[UIColor grayColor]];
    line2.alpha=0.3;
    [bgView addSubview:line2];
    
}


-(void)createLabel
{
    
    
}








- (void)initView
{
    _formTable = [[UITableView alloc] initWithFrame:CGRectMake(0, kNavigationBarHeight, kScreenWidth, kScreenHeight - kScreenHeight) style:UITableViewStylePlain];
    _formTable.showsVerticalScrollIndicator = NO;
    _formTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    _formTable.backgroundColor = [UIColor clearColor];
    [self.view addSubview:_formTable];
    
    _formManager = [[RETableViewManager alloc] initWithTableView:_formTable];
    _formManager.delegate = self;
    _formManager[@"FMEmptyItem"] = @"FMEmptyCell";
    
}
#pragma mark - RETableViewManagerDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)sectionIndex{
    return 0;
}

- (void)addHeader {
//    WSCustomRefreshHeader *header = [WSCustomRefreshHeader headerWithRefreshingTarget:self refreshingAction:@selector(getData)];
//    // 隐藏时间
//    header.lastUpdatedTimeLabel.hidden = YES;
//    // 隐藏状态
//    header.stateLabel.hidden = YES;
//    // 设置header
//    self.formTable.mj_header = header;
}
#pragma mark - 右键直接跳回某个viewcontroller
-(NSMutableArray*)rightBtnClickedPopToOneViewCotroller:(NSString *)classString{
    int m = 0;
    int n = 0;
    NSMutableArray *viewControllers=[NSMutableArray arrayWithArray:self.navigationController.viewControllers];
    for (int i = 0; i < viewControllers.count; i ++) {
        UIViewController *controller = [viewControllers objectAtIndex:i];
        m++;
        if ([controller isKindOfClass:NSClassFromString(classString)]){
            n = m;
        }
    }
    for (int j = 0; j < m - n; j++) {
        [viewControllers removeLastObject];
    }
    return viewControllers;
}

-(void)formTableReload{
    [sectionArray addObject:section0];
    [self.formManager replaceSectionsWithSectionsFromArray:sectionArray];
    [self.formTable reloadData];
}
@end
