//
//  AppConfig.h
//  FMBaseProject
//
//  Created by shanjin on 2017/5/25.
//  Copyright © 2017年 付新明. All rights reserved.
//

#ifndef AppConfig_h
#define AppConfig_h
#define appkey_1 @"027bcbf36860c4a3"
#define ServerHost @"https://apiapi.oomeng.cn"


#endif /* AppConfig_h */
